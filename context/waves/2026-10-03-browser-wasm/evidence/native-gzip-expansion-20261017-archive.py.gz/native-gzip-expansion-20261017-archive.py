import gzip,hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
out=root/'context/waves/2026-10-03-browser-wasm/evidence';prefix='native-gzip-expansion-20261017';files=[]
def retain(label,path,compressed=False):
 raw=(root/path).read_bytes();dest=out/(prefix+'-'+label+('.gz' if compressed else ''))
 assert not dest.exists(),dest
 dest.write_bytes(gzip.compress(raw,mtime=0) if compressed else raw)
 entry={'file':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'original_path':path}
 if compressed:
  assert gzip.decompress(dest.read_bytes())==raw
  entry['expanded_sha256']=hashlib.sha256(raw).hexdigest()
 files.append(entry)
runs=[]
for label,directory in zip(['candidate-first','control-second','control-reverse','candidate-reverse'],sys.argv[1:],strict=True):
 report=json.loads((root/directory/'report.json').read_text())
 assert report['completed'] and len(report['packages'])==75 and len(report['imports'])==2 and len(report['warm_query_ms'])==20 and not report['missing_sampled_phases']
 retain(label+'-report.json',directory+'/report.json');retain(label+'-samples.json',directory+'/samples.json',True)
 runs.append({'label':label,'private_peak_mib':report['sampled_peak_private_bytes']/1048576,
  'blank_peak_mib':next(x['peak_private_bytes']/1048576 for x in report['memory'] if x['phase']=='blank_browser'),
  'warm_max_ms':max(report['warm_query_ms']),'target':report['provisional_250_mib_target'],'artifact':report['artifact']})
for label,path in [
 ('abi-report.json','target/native-gzip-abi-report.json'),
 ('context-report.json','target/catalog-context-wA1fnc/report.json'),
 ('offline-report.json','target/browser-acceptance-1n4oEs/report.json'),
 ('canonical-refusal-report.json','target/native-gzip-canonical-refusal-dqQODa/report.json'),
 ('crc-fixture-failure.json','target/native-gzip-crc-refusal-2CxdEx/report.json'),
 ('crc-refusal-report.json','target/native-gzip-crc-refusal-L98dop/report.json'),
 ('build-info.json','target/native-gzip-expansion-artifact/build-info.json'),
 ('shell-manifest.json','target/native-gzip-expansion-artifact/shell-manifest.json')]:retain(label,path)
for label,path in [
 ('full-build.log','target/native-gzip-full-build.log'),('rust-tests.log','target/native-gzip-rust-tests.log'),
 ('adapter-worker-tests.log','target/native-gzip-adapter-worker-tests.log'),('feature-tree.log','target/native-gzip-feature-tree.log'),
 ('abi.mjs','target/native-gzip-abi.mjs'),('prepare-refusals.py','target/prepare-native-gzip-refusals.py'),
 ('initial-crc-fixture.mjs','target/native-gzip-crc-refusal-initial.mjs'),('crc-fixture.mjs','target/native-gzip-crc-refusal.mjs'),
 ('canonical-fixture.mjs','target/native-gzip-canonical-refusal.mjs'),('archive.py','target/archive-native-gzip.py')]:retain(label,path,True)
manifest={'schema_version':1,'scope':'Local bounded native gzip prototype, unchanged original Windows75/eight/two/20/restart workload and sampler/flags/channel, no forced GC or baseline-subtracted acceptance. No publication/device claim.',
 'source':'0079d0bf2ff4ac3f2b24fe3cd489a058af26f300','control_source':'807e2adcd31cdd8cd31a74f87fdeec05247b7ef0',
 'comparison_limit':'Retained control includes source-history differences; same pinned Windows compiler/profile. These pairs are observations, not exact causal attribution.',
 'decision':'Unadopted;250 MiB remains failed. Assess both orderings without discarding any observation.',
 'fixture_failure':'Initial CRC route used Uint8Array body and timed out with Loading status. Corrected to Buffer and explicit fulfilled-route assertion; original false report/script retained. No application change was needed.',
 'runs':runs,'files':files}
dest=out/(prefix+'-manifest.json');assert not dest.exists()
dest.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print(json.dumps(runs,indent=2))
