import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import init,{BrowserEngine,package_digest} from '../icelines-browser/dist/pkg/icelines_wasm.js';
const root=new URL('../icelines-browser/dist/',import.meta.url);
const wasm=await readFile(new URL('pkg/icelines_wasm_bg.wasm',root));await init({module_or_path:wasm});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const catalog=JSON.parse(await readFile(new URL('catalog.json',root),'utf8'));
const engine=new BrowserEngine();
const query=JSON.stringify({filter:'',sort:'points',goalies:false,minimum_games:0,today:'2026-01-01'});
const snapshot=()=>({residents:engine.resident_revisions(),metadata:engine.package_metadata(),query:engine.query(query)});
try{
  for(const entry of catalog.packages.slice(0,2))engine.load_package(await readFile(new URL(entry.url,root)));
  assert.equal(JSON.parse(engine.resident_revisions()).length,2);
  const before=snapshot();
  const payloads=[new Uint8Array(),new TextEncoder().encode('abc'),new TextEncoder().encode('Slafkovský · Sebastian Aho'),Uint8Array.from({length:8*1024*1024+17},(_,i)=>i%251)];
  for(const bytes of payloads){
    const padded=new Uint8Array(bytes.length+12);padded.fill(0xff);padded.set(bytes,7);const original=padded.slice();
    const view=padded.subarray(7,7+bytes.length);assert.equal(package_digest(view),hash(bytes));assert.deepEqual(padded,original);assert.deepEqual(snapshot(),before);
  }
  assert.throws(()=>package_digest(new Uint8Array(100*1024*1024+1)),/100 MiB/);
  assert.deepEqual(snapshot(),before);
  const report={verified:true,scope:'Actual freshly built WASM in Node. SHA/offset/oversize/native-state preservation only; no browser memory or deployment acceptance.',wasm_sha256:hash(wasm),cases:payloads.length,input_offset_preserved:true,oversize_refused:true,two_resident_windows_and_complete_query_unchanged:true};
  await writeFile(new URL('./native-package-digest-abi-report.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report));
}finally{engine.free();}
