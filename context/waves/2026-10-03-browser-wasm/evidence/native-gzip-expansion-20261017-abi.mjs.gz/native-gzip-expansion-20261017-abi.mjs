import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import init,{BrowserEngine,expand_catalog_gzip} from './native-gzip-expansion-artifact/pkg/icelines_wasm.js';
const root=new URL('./native-gzip-expansion-artifact/',import.meta.url);
const wasm=await readFile(new URL('pkg/icelines_wasm_bg.wasm',root));const native=await init({module_or_path:wasm});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const catalog=JSON.parse(await readFile(new URL('catalog.json',root),'utf8'));
const engine=new BrowserEngine();
const query=JSON.stringify({filter:'',sort:'points',goalies:false,minimum_games:0,today:'2026-01-01'});
const snapshot=()=>({residents:engine.resident_revisions(),metadata:engine.package_metadata(),query:engine.query(query)});
try{
 for(const entry of catalog.packages.slice(0,2))engine.load_package(await readFile(new URL(entry.url,root)));
 const before=snapshot();assert.equal(JSON.parse(before.residents).length,2);
 for(const entry of catalog.packages){
  const wire=await readFile(new URL(entry.transport.url,root));const raw=await readFile(new URL(entry.url,root));
  const padded=new Uint8Array(wire.length+16);padded.fill(255);padded.set(wire,7);const original=padded.slice();
  const decoded=expand_catalog_gzip(padded.subarray(7,7+wire.length),entry.bytes);
  assert.deepEqual(decoded,new Uint8Array(raw));assert.equal(hash(decoded),entry.sha256);assert.notEqual(decoded.buffer,native.memory.buffer);assert.deepEqual(padded,original);assert.deepEqual(snapshot(),before);
 }
 const raw=Uint8Array.from({length:8*1024*1024+17},(_,i)=>i%251);assert.deepEqual(expand_catalog_gzip(gzipSync(raw),raw.length),raw);
 const wire=new Uint8Array(gzipSync('abc'));const crc=wire.slice();crc[crc.length-8]^=1;
 for(const bytes of [crc,wire.subarray(0,wire.length-1),new Uint8Array([...wire,42]),new TextEncoder().encode('not gzip')])assert.throws(()=>expand_catalog_gzip(bytes,3),/Invalid gzip/);
 assert.deepEqual(expand_catalog_gzip(new Uint8Array([...wire,...gzipSync('def')]),6),new TextEncoder().encode('abcdef'));
 assert.throws(()=>expand_catalog_gzip(new Uint8Array([...wire,...gzipSync('def')]),3),/exceeds/);
 assert.throws(()=>expand_catalog_gzip(gzipSync(new Uint8Array(1024*1024)),128),/exceeds/);
 for(const maximum of [0,100*1024*1024+1])assert.throws(()=>expand_catalog_gzip(wire,maximum),/Invalid gzip byte limit/);
 assert.deepEqual(expand_catalog_gzip(gzipSync(''),1),new Uint8Array());assert.deepEqual(snapshot(),before);
 const report={verified:true,scope:'Actual fresh WASM in Node:75 package byte/offset/state comparisons,8 MiB patterned payload, CRC/truncation/trailing/member/bomb/output-limit refusal. Not browser memory, cancellation, production or device acceptance.',wasm_sha256:hash(wasm),packages:catalog.packages.length,two_resident_windows_and_complete_query_unchanged:true,outputs_own_buffers:true};
 await writeFile(new URL('./native-gzip-abi-report.json',import.meta.url),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
}finally{engine.free();}
