import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent.parent
before=root/'target/wasm-validation-75e6ba97'
after=root/sys.argv[1]
excluded={'build-info.json','shell-manifest.json','sw.js'}
def inventory(directory):
 return {p.relative_to(directory).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
  for p in directory.rglob('*') if p.is_file() and p.relative_to(directory).as_posix() not in excluded}
a,b=inventory(before),inventory(after)
differences=[p for p in sorted(a.keys()|b.keys()) if a.get(p)!=b.get(p)]
report={'verified':not differences,'scope':'Exact retained published-release versus CI file hashes, excluding three build-identity-dependent files. No executing-bytecode, offline, memory or device claim.',
 'release':json.loads((before/'build-info.json').read_text()),'candidate':json.loads((after/'build-info.json').read_text()),
 'excluded':sorted(excluded),'compared_files':len(a),'differences':differences}
assert len(a)==179 and len(b)==179
print(json.dumps(report,indent=2))
assert not differences,differences
