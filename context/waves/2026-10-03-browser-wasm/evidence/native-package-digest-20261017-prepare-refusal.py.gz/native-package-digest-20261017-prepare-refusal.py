from pathlib import Path
s=Path('icelines-browser/e2e/catalog-context.mjs').read_text(encoding='utf-8')
s=s.replace("from '@playwright/test'","from '../icelines-browser/node_modules/@playwright/test/index.mjs'").replace("'../..'","'..'").replace('target/catalog-context-','target/native-digest-refusal-')
a=s.index('  for(const cached of [false,true]) {')
b=s.index('  currentCatalog={...published,packages:[first,second]};await reload();await load(second);',a)
s=s[:a]+"""  const fakeHash='0'.repeat(64);
  const invalid={...second,sha256:fakeHash,url:`data/${fakeHash}.json`,transport:{...second.transport,url:`data/${fakeHash}.json.gz`}};
  const validWire=await readFile(resolve(root,second.transport.url));
  currentCatalog={...published,packages:[first,invalid]};
  await page.route('**/'+invalid.transport.url,route=>route.fulfill({status:200,body:validWire,contentType:'application/gzip'}));
  await reload();await load(invalid);
  await expect(page.locator('#status')).toContainText('Package size or checksum mismatch');
  assert.equal(await page.locator('#context').textContent(),baseline);
  await expect(page.locator('#rows')).toHaveAttribute('data-result-count',String(first.skaters));
  const [download]=await Promise.all([page.waitForEvent('download'),page.locator('#export-package').click()]);
  assert.deepEqual(await readFile(await download.path()),await readFile(resolve(root,first.url)));
  await page.locator('#query button[type="submit"]').click();await expect(page.locator('#rows')).toHaveJSProperty('inert',false);
  outcomes.push({compressed_wire_authentic:true,raw_digest_mismatch_rejected:true,previous_rows:first.skaters,exact_previous_export:true,requery:true});
  await page.unroute('**/'+invalid.transport.url);
"""+s[b:]
s=s.replace("report.scope='Owned browser with intentionally unsigned two-entry catalog and unavailable offline-shell cache; fixture invokes hidden reload handler after swapping catalog; catalog mismatch fresh/cached rejection, previous-good full result/exact package export/requery and retry. Not offline, memory, production or phone proof.'", "report.scope='Actual native digest worker with authentic compressed bytes/wire hash but wrong advertised canonical digest. Unsigned two-entry catalog/reload fixture; previous-good result/exact export/requery and retry. Not offline/memory/mobile/publication proof.'")
Path('target/native-digest-refusal.mjs').write_text(s,encoding='utf-8')
print('Prepared genuine wire / wrong canonical digest native-backend refusal fixture')
