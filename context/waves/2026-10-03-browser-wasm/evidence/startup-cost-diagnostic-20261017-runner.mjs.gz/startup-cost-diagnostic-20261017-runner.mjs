// Supplemental reduced-workload diagnosis. Never resource acceptance.
import {chromium,expect} from '../icelines-browser/node_modules/@playwright/test/index.mjs';
import {createServer} from 'node:http';
import {mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {spawn,spawnSync} from 'node:child_process';
import {createInterface} from 'node:readline';
const repository=resolve(import.meta.dirname,'..');
const root=resolve(repository,'target/wasm-validation-75e6ba97');
const output=await mkdtemp(resolve(repository,'target/startup-cost-probe-'));
const info=JSON.parse(await readFile(resolve(root,'build-info.json'),'utf8'));
const shell=JSON.parse(await readFile(resolve(root,'shell-manifest.json'),'utf8'));
const verify=spawnSync('python',['scripts/verify-browser-artifact.py',root,info.commit,shell.build],{cwd:repository,encoding:'utf8'});
if(verify.status!==0)throw Error(verify.stderr);
const report={verified:false,acceptance:null,scope:'Reduced startup-only diagnostic, three fresh owned browsers with default benchmark launch options and original Windows sampler. No packages/imports/warm queries or restart workload. Never250 MiB acceptance, causal ownership or impossibility proof.',artifact:JSON.parse(verify.stdout),arms:[]};
let arm;const prefix='/ICELINES/workbench/';
const server=createServer(async(req,res)=>{try{
 const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
 if(!path.startsWith(prefix))throw Error('outside prefix');
 const relative=path.slice(prefix.length)||'index.html';const file=resolve(root,relative);
 if(!file.startsWith(root+sep))throw Error('outside artifact');
 if(relative==='index.html'&&arm==='empty')return res.writeHead(200,{'Content-Type':'text/html'}).end('<!doctype html><meta charset="utf-8"><title>Startup control</title><p>Startup control</p>');
 let bytes=await readFile(file);
 if(relative==='index.html'&&arm==='static'){
  const text=bytes.toString('utf8');const module='<script type="module" src="./src/main.js"></script>';
  if(text.split(module).length!==2)throw Error('Expected one exact module script');
  bytes=Buffer.from(text.replace(module,''));
 }
 res.writeHead(200,{'Content-Type':({'.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','.wasm':'application/wasm'})[extname(file)]??'application/octet-stream','Cache-Control':'no-store'}).end(bytes);
}catch{res.writeHead(404).end();}});
let failure;
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 for(arm of ['empty','static','normal']){
  const samples=[];let phase='blank_browser';let browserServer,browser,sampler;let finished,exitCode;let stderr='';
  const stopFile=resolve(output,arm+'-stop');
  try{
   browserServer=await chromium.launchServer({channel:'chromium',headless:true});browser=await chromium.connect(browserServer.wsEndpoint());
   report.browser=browser.version();
   sampler=spawn('powershell.exe',['-NoProfile','-File',resolve(repository,'icelines-browser/e2e/sample-browser-memory.ps1'),'-RootProcessId',String(browserServer.process().pid),'-StopFile',stopFile],{windowsHide:true,stdio:['ignore','pipe','pipe']});
   finished=new Promise(r=>{sampler.once('error',e=>{stderr+=String(e);});sampler.once('close',code=>{exitCode=code;r();});});
   sampler.stderr.on('data',data=>{stderr+=data;});
   createInterface({input:sampler.stdout}).on('line',line=>{try{samples.push({phase,...JSON.parse(line)});}catch(e){stderr+=String(e);}});
   const context=await browser.newContext({serviceWorkers:'allow',viewport:{width:1280,height:800}});const page=await context.newPage();
   const requests=[];page.on('request',req=>requests.push(new URL(req.url()).pathname));
   await expect.poll(()=>samples.length,{timeout:15000}).toBeGreaterThan(3);
   phase='startup';await page.goto(`http://127.0.0.1:${server.address().port}${prefix}`);
   if(arm==='normal')await expect(page.locator('#catalog option').first()).toBeAttached({timeout:60000});
   else await expect(page.locator(arm==='static'?'#catalog':'p')).toBeAttached();
   await expect.poll(()=>samples.filter(s=>s.phase==='startup').length,{timeout:15000}).toBeGreaterThanOrEqual(8);
   await writeFile(stopFile,'stop');await finished;
   if(exitCode!==0||stderr)throw Error('Sampler failed: '+stderr);
   const peak=name=>Math.max(...samples.filter(s=>s.phase===name).map(s=>s.processes.reduce((sum,p)=>sum+p.private_bytes,0)))/1048576;
   report.arms.push({arm,blank_private_peak_mib:peak('blank_browser'),startup_private_peak_mib:peak('startup'),wasm_requests:requests.filter(p=>p.endsWith('.wasm')).length,samples:arm+'-samples.json'});
  }finally{
   if(sampler&&exitCode===undefined){await writeFile(stopFile,'stop');await finished;}
   await browser?.close();await browserServer?.close();await writeFile(resolve(output,arm+'-samples.json'),JSON.stringify(samples)+'\n');
  }
 }
 report.verified=true;
}catch(error){failure=error;report.error=String(error);}
finally{await new Promise(r=>server.close(r));await writeFile(resolve(output,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(output,JSON.stringify(report));}
if(failure)throw failure;
