import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
source=root/'target/buffer-heap-bridge-BnBxro';report=json.loads((source/'report.json').read_text())
summary=json.loads((root/'target/renderer-effective-allocator-summary.json').read_text())
assert report['completed'] and report['provisional_250_mib_target'] is None and len(summary['checkpoints'])==9
out=root/'context/waves/2026-10-03-browser-wasm/evidence';prefix='renderer-effective-allocators-20261017';files=[]
def keep(label,path,compressed):
 raw=path.read_bytes();dest=out/(prefix+'-'+label+('.gz' if compressed else ''));assert not dest.exists(),dest
 dest.write_bytes(gzip.compress(raw,mtime=0) if compressed else raw)
 entry={'file':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'original_path':path.relative_to(root).as_posix()}
 if compressed:
  assert gzip.decompress(dest.read_bytes())==raw
  entry['expanded_sha256']=hashlib.sha256(raw).hexdigest()
 files.append(entry)
for c in report['heap_checkpoints']:
 path=source/c['label']/c['mapping']['trace']['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==c['mapping']['trace']['sha256']
 keep(c['label']+'-trace.json',path,True)
keep('source-report.json',source/'report.json',True)
keep('summary.json',root/'target/renderer-effective-allocator-summary.json',False)
keep('analyze.py',root/'target/analyze-renderer-effective-allocators.py',True)
keep('archive.py',Path(__file__),True)
manifest={'schema_version':1,'acceptance':None,'scope':summary['scope'],'artifact':summary['artifact'],
 'decision':'No new runtime optimization or allocator ownership claim follows from unspecified bytes. Continue only with stronger allocation-site evidence;250 MiB remains unmet, Android deferred.',
 'findings':'Before engine: allocator-owned malloc effective20.43 MiB, partition_alloc6.56, V8 6.82, Blink objects2.77, Blink overhead1.36, compositor10. At eight: array_buffer allocated31.04 MiB; after warm queries7.50 MiB. Main V8 heap is much smaller than the whole renderer. Unspecified native categories remain unnamed. Do not sum root/descendant size or reservations/limits.',
 'primary_reference':summary['primary_reference'],'files':files}
dest=out/(prefix+'-manifest.json');assert not dest.exists()
dest.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print('Retained',len(files),'files with acceptance=null')
