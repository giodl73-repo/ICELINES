from pathlib import Path
root=Path(__file__).resolve().parent.parent
original=(root/'target/native-digest-refusal.mjs').read_text()
def change(text,old,new):
 assert text.count(old)==1,old
 return text.replace(old,new)
canonical=change(original,'target/native-digest-refusal-','target/native-gzip-canonical-refusal-')
canonical=change(canonical,'Actual native digest worker with authentic compressed bytes/wire hash but wrong advertised canonical digest.','Actual native gzip expansion with authentic compressed bytes/wire hash but wrong advertised canonical digest.')
(root/'target/native-gzip-canonical-refusal.mjs').write_text(canonical,encoding='utf-8')
crc=change(original,"import assert from 'node:assert/strict';","import assert from 'node:assert/strict';\nimport {createHash} from 'node:crypto';")
crc=change(crc,'target/native-digest-refusal-','target/native-gzip-crc-refusal-')
start=crc.index("  const fakeHash='0'.repeat(64);")
end=crc.index('  currentCatalog={...published,packages:[first,invalid]};',start)
crc=crc[:start]+'''  const validWire=await readFile(resolve(root,second.transport.url));
  validWire[validWire.length-8]^=1;
  const invalid={...second,transport:{...second.transport,sha256:createHash('sha256').update(validWire).digest('hex')}};
'''+crc[end:]
crc=change(crc,"toContainText('Package size or checksum mismatch')","toContainText('Invalid gzip')")
crc=change(crc,"  await page.route('**/'+invalid.transport.url,route=>route.fulfill({status:200,body:validWire,contentType:'application/gzip'}));", "  let payloadServed=0;\n  await page.route('**/'+invalid.transport.url,async route=>{await route.fulfill({status:200,body:validWire,contentType:'application/gzip'});payloadServed++;});")
crc=change(crc,'  await reload();await load(invalid);','  await reload();await load(invalid);\n  await expect.poll(()=>payloadServed,{timeout:10000}).toBe(1);')
crc=change(crc,'compressed_wire_authentic:true,raw_digest_mismatch_rejected:true','wire_digest_matches_corrupt_gzip:true,crc_failure_rejected:true')
crc=change(crc,'Actual native digest worker with authentic compressed bytes/wire hash but wrong advertised canonical digest.','Actual native WASM gzip decoder refuses invalid CRC after wire size/hash match. Canonical entry unchanged.')
(root/'target/native-gzip-crc-refusal.mjs').write_text(crc,encoding='utf-8')
