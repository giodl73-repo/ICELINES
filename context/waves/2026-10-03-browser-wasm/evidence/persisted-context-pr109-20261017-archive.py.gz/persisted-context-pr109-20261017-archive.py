import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
out=root/'context/waves/2026-10-03-browser-wasm/evidence'
prefix='persisted-context-pr109-20261017'
checks=json.loads((root/'target/persisted-context-pr109-merge-time-checks.json').read_text())
assert checks and all(x['state'] in ('SUCCESS','SKIPPED','IN_PROGRESS') for x in checks)
pending=[x['name'] for x in checks if x['state']=='IN_PROGRESS']
assert set(pending)<= {'Window fingerprint / windows-latest'}
assert sum(x['state']=='SUCCESS' for x in checks)>=26
pr=json.loads((root/'target/persisted-context-pr109-merged.json').read_text())
assert pr['state']=='MERGED' and pr['headRefOid']=='829bf5e938223f784012b89f1983558d67696905'
files=[]
for label,path,compressed in [
 ('browser-report.json','target/persisted-catalog-context-GDFNGv/report.json',False),
 ('runtime-comparison.json','target/persisted-context-pr109-runtime-comparison.json',False),
 ('merge-time-checks.json','target/persisted-context-pr109-merge-time-checks.json',False),
 ('merged.json','target/persisted-context-pr109-merged.json',False),
 ('source.json','target/persisted-context-pr109-source.json',False),
 ('compare.py','target/compare-persisted-context-artifact.py',True),
 ('archive.py','target/archive-persisted-context-ci.py',True),
]:
 raw=(root/path).read_bytes();dest=out/(prefix+'-'+label+('.gz' if compressed else ''))
 assert not dest.exists(),dest
 dest.write_bytes(gzip.compress(raw,mtime=0) if compressed else raw)
 item={'file':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'original_path':path}
 if compressed:
  assert gzip.decompress(dest.read_bytes())==raw
  item['expanded_sha256']=hashlib.sha256(raw).hexdigest()
 files.append(item)
manifest={'schema_version':1,'scope':'PR109 source/CI artifact custody and supplemental IndexedDB browser validation. Merge-time check snapshot: remaining Windows fingerprint is pending, not passed. No claim of full native CI, publication, memory or Android acceptance.',
 'head':'829bf5e938223f784012b89f1983558d67696905','preview_source':'34b0226bafa5401104f100154f8871f538f0d3ad',
 'browser_run':39079066084,'native_run':39079066044,'artifact_id':12118268272,
 'unchanged_runtime_files':179,'identity_file_exclusions':['build-info.json','shell-manifest.json','sw.js'],
 'checks_success':sum(x['state']=='SUCCESS' for x in checks),'checks_skipped':sum(x['state']=='SKIPPED' for x in checks),
 'pending_at_merge':pending,
 'merge_basis':'Test/evidence/docs and npm command only; no application/data/schema changes. Exact CI browser test passes and179 files match published runtime outside three build-identity files. Other28 checks pass; remaining nonrequired fingerprint tests unchanged native code. Branch protection does not require status checks. This decision does not waive a release acceptance gate.',
 'merge_commit':pr['mergeCommit']['oid'],'files':files}
dest=out/(prefix+'-manifest.json');assert not dest.exists()
dest.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
