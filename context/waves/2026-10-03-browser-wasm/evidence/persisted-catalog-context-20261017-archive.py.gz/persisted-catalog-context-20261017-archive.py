import gzip, hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
out=root/'context/waves/2026-10-03-browser-wasm/evidence'
prefix='persisted-catalog-context-20261017'
files=[]
for label,path,compressed in [
 ('final-report.json','target/persisted-catalog-context-nNtnoZ/report.json',False),
 ('first-pass-report.json','target/persisted-catalog-context-V9feVT/report.json',False),
 ('resident-fixture-failure.json','target/persisted-catalog-context-eIB6AF/report.json',False),
 ('panel-fixture-failure.json','target/persisted-catalog-context-KiKiNs/report.json',False),
 ('download-browser-failure.json','target/persisted-catalog-context-z1oDgQ/report.json',False),
 ('runner.mjs','icelines-browser/e2e/persisted-catalog-context.mjs',True),
 ('archive.py','target/archive-persisted-context.py',True),
]:
 raw=(root/path).read_bytes();dest=out/(prefix+'-'+label+('.gz' if compressed else ''))
 assert not dest.exists(),dest
 dest.write_bytes(gzip.compress(raw,mtime=0) if compressed else raw)
 item={'original_path':path,'file':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
 if compressed:
  assert gzip.decompress(dest.read_bytes())==raw
  item['expanded_sha256']=hashlib.sha256(raw).hexdigest()
 files.append(item)
manifest={'schema_version':1,'scope':'Supplemental actual IndexedDB saved-context validation on retained release75e6ba97. No runtime edits, deployment, resource/device acceptance or offline-shell claim.',
 'fixture':'Unsigned two-entry catalog; service workers blocked; owned profile reopened once before three cases; candidate absent from resident library, actual IndexedDB get observed, candidate payload unavailable; previous933 rows/export/requery and saved905 retry verified.',
 'failures':'Three earlier fixture/browser failures retained as failures, never relabeled passing. First restored candidate resident at startup; second redundant load raced panel folding; third repeated reopening with downloads encountered page/context/browser closure. Final runner avoids repeated post-download process reopen without changing application or stored data.',
 'files':files}
dest=out/(prefix+'-manifest.json');assert not dest.exists()
dest.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(files),'files')
