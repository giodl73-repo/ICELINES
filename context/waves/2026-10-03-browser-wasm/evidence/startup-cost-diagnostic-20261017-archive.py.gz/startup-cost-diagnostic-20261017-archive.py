import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
source=root/'target/startup-cost-probe-SVdOyV'
out=root/'context/waves/2026-10-03-browser-wasm/evidence'
prefix='startup-cost-diagnostic-20261017'
report=json.loads((source/'report.json').read_text())
assert report['verified'] and report['acceptance'] is None
assert all(x['wasm_requests']==0 for x in report['arms'])
files=[]
for label,path,compressed in [('report.json',source/'report.json',False),
 *[(arm+'-samples.json',source/(arm+'-samples.json'),True) for arm in ['empty','static','normal']],
 ('runner.mjs',root/'target/startup-cost-probe.mjs',True),('archive.py',Path(__file__),True)]:
 raw=path.read_bytes();dest=out/(prefix+'-'+label+('.gz' if compressed else ''))
 assert not dest.exists(),dest
 dest.write_bytes(gzip.compress(raw,mtime=0) if compressed else raw)
 entry={'file':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'original_path':path.relative_to(root).as_posix()}
 if compressed:
  assert gzip.decompress(dest.read_bytes())==raw
  entry['expanded_sha256']=hashlib.sha256(raw).hexdigest()
 files.append(entry)
manifest={'schema_version':1,'acceptance':None,'scope':report['scope'],
 'decision':'Investigate startup presentation/service-worker/module costs before further checksum experiments. This one short diagnostic does not establish causal component ownership, a memory floor or feasibility/impossibility of250 MiB.',
 'limits':'Reduced workload; one empty/static/normal sequence of fresh browsers; eight startup samples minimum per arm; differing blank baselines retained; no package workload, forced GC, flag/channel/sampler changes, normal acceptance or device claim. Page request observer reports zero WASM requests; it is not worker/process attribution.',
 'arms':report['arms'],'files':files}
dest=out/(prefix+'-manifest.json');assert not dest.exists()
dest.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(files),'files; acceptance=null')
