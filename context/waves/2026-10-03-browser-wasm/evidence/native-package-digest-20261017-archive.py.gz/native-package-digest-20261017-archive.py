import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sys

root = Path(__file__).resolve().parent.parent
out = root / 'context/waves/2026-10-03-browser-wasm/evidence'
prefix = 'native-package-digest-20261017'
entries = []
def retain(label, relative, compressed=False):
    source = root / relative
    raw = source.read_bytes()
    name = prefix + '-' + label + ('.gz' if compressed else '')
    dest = out / name
    if dest.exists():
        raise RuntimeError(f'Refusing overwrite: {dest}')
    dest.write_bytes(gzip.compress(raw, mtime=0) if compressed else raw)
    entry = {'label': label, 'original_path': relative, 'file': name,
             'sha256': hashlib.sha256(dest.read_bytes()).hexdigest()}
    if compressed:
        assert gzip.decompress(dest.read_bytes()) == raw
        entry['expanded_sha256'] = hashlib.sha256(raw).hexdigest()
    entries.append(entry)

summaries = {}
for label, directory in [('candidate', 'target/browser-memory-xasfnd'), ('control', sys.argv[1])]:
    report = json.loads((root / directory / 'report.json').read_text())
    assert report['completed'] and len(report['packages']) == 75
    assert len(report['warm_query_ms']) == 20 and not report['missing_sampled_phases']
    retain(label + '-report.json', directory + '/report.json')
    retain(label + '-samples.json', directory + '/samples.json', True)
    summaries[label] = {'private_peak_mib': report['sampled_peak_private_bytes'] / 1048576,
        'blank_private_peak_mib': next(x['peak_private_bytes'] for x in report['memory'] if x['phase'] == 'blank_browser') / 1048576,
        'warm_max_ms': max(report['warm_query_ms']),
        'target': report['provisional_250_mib_target'], 'artifact': report['artifact']}

for label, path in [
    ('abi-report.json', 'target/native-package-digest-abi-report.json'),
    ('context-report.json', 'target/catalog-context-Xatv88/report.json'),
    ('offline-report.json', 'target/browser-acceptance-UaY3Xc/report.json'),
    ('transport-refusal-report.json', 'target/gzip-delivery-refusal-vRdNMt/report.json'),
    ('canonical-refusal-report.json', 'target/native-digest-refusal-Y1JjR8/report.json'),
]:
    retain(label, path)
for label, path in [
    ('full-build.log', 'target/native-package-digest-full-build.log'),
    ('worker-tests.log', 'target/native-package-digest-permanent-worker-tests.log'),
    ('rust-tests.log', 'target/native-package-digest-rust-tests.log'),
    ('abi.mjs', 'target/native-package-digest-abi.mjs'),
    ('prepare-refusal.py', 'target/prepare-native-digest-refusal.py'),
    ('canonical-refusal.mjs', 'target/native-digest-refusal.mjs'),
    ('archive.py', 'target/archive-native-digest.py'),
]:
    retain(label, path, True)
manifest = {'schema_version': 1, 'scope': 'Local native-checksum prototype, not adopted or published. Normal full Windows workload; no forced GC, adjusted flags, baseline subtraction or device claim.',
    'source': 'd9b93cf859a4140789ee5e8a5659df57ef856718',
    'decision': 'Do not adopt: no demonstrated saving; 250 MiB target remains failed. Android deferred by user.',
    'comparison_limit': 'One candidate-first pair against retained Windows pre-prototype engine; same compiler/profile. Includes source-history differences; not exact causal attribution.',
    'runs': summaries, 'files': entries}
path = out / (prefix + '-manifest.json')
assert not path.exists()
path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summaries, indent=2))
