import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent/'buffer-heap-bridge-BnBxro'
r=json.loads((root/'report.json').read_text());assert r['completed'] and r['provisional_250_mib_target'] is None
result={'acceptance':None,'scope':'Reanalysis of existing additional-observer control traces, source807e2ad. Effective allocator sizes are provider/ownership-accounted component metrics, not Windows private-byte partition, physical RAM or a normal benchmark. Ancestor and child nodes overlap; never sum both. Virtual reservations, hard limits and maxima are not current allocations.',
 'primary_reference':'https://chromium.googlesource.com/chromium/src/+/lkgr/docs/memory-infra/',
 'artifact':r['artifact'],'checkpoints':[]}
for c in r['heap_checkpoints']:
 m=c['mapping'];path=root/c['label']/m['trace']['file'];raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==m['trace']['sha256']
 events=json.loads(raw)['traceEvents'];guid=m['memory_dump']['dumpGuid']
 starts=[e for e in events if e.get('name')=='GlobalMemoryDump' and e.get('ph')=='b' and e.get('args',{}).get('dump_guid')==guid];assert len(starts)==1;b=starts[0]
 ends=[e for e in events if e.get('name')=='GlobalMemoryDump' and e.get('ph')=='e' and e.get('id2')==b.get('id2') and e['pid']==b['pid'] and e['ts']>=b['ts']];assert len(ends)==1
 pages=[t for t in m['targets'] if t['type']=='page'];assert len(pages)==1 and pages[0]['mapped'];pid=pages[0]['renderer_pid'];alloc={}
 for e in events:
  if e['pid']!=pid or not b['ts']<=e.get('ts',-1)<=ends[0]['ts']:continue
  for name,v in e.get('args',{}).get('dumps',{}).get('allocators',{}).items():
   if name=='global' or name.startswith('global/'):continue
   assert name not in alloc;alloc[name]=v
 def metrics(v):return {k:int(x['value'],16) for k,x in v.get('attrs',{}).items() if x.get('type')=='scalar' and x.get('units')=='bytes' and k in ['size','effective_size','allocated_objects_size','virtual_committed_size','decommittable_size','discardable_size','wasted','committed_size','pooled_size']}
 roots={name:metrics(v) for name,v in alloc.items() if '/' not in name}
 selected={name:metrics(v) for name,v in alloc.items() if name.startswith(('v8/main/heap/','v8/workers/','malloc/win_heap','malloc/metadata_fragmentation_caches','partition_alloc/allocated_objects/')) or name in ['malloc/allocated_objects/<unspecified>','malloc/partitions/allocator','malloc/partitions/allocator/thread_cache','partition_alloc/partitions/buffer','partition_alloc/partitions/array_buffer','blink_gc/main/heap']}
 result['checkpoints'].append({'label':c['label'],'renderer_pid':pid,'trace_file':str(path.relative_to(root)),'trace_sha256':m['trace']['sha256'],'dump_guid':guid,'root_metrics':roots,'selected_overlapping_nodes':selected})
 assert all(x.get('effective_size',0)>=0 for x in roots.values())
assert len(result['checkpoints'])==9
out=Path(__file__).resolve().parent/'renderer-effective-allocator-summary.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for c in result['checkpoints']:
 print(c['label'],{k:round(v['effective_size']/1048576,2) for k,v in c['root_metrics'].items() if v.get('effective_size',0)>=1048576})
 print(' malloc-unspecified MiB',c['selected_overlapping_nodes'].get('malloc/allocated_objects/<unspecified>',{}).get('effective_size',0)/1048576)
